print("Hello World")

size = int(input("Enter size of matrix: "))
matrix = [[0] * size for row in range(0, size)]
for x in range(0, size):

    line = list(map(int, input().split()))

    for y in range(0, size):
        matrix[x][y] = line[y]

diagonal_sum = sum(matrix[size - i - 1][size - i - 1] for i in range(size))
print("sum of diagonal:")
print(diagonal_sum)