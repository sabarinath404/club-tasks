

input = int(input("enter the number: "))
print(input)




	




  
k = 2*input - 2
  
   
for i in range(input):
      
        
        for j in range(k):
            print(end=" ")
      
       
        k = k - 2
      
     
        for j in range(0, i+1):
          
            
            print("* ", end="")
      
     
        print("\r")
  

